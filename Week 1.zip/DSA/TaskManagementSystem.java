public class TaskManagementSystem {

    public static class Task {
        private final String taskId;
        private final String taskName;
        private final String status;
        private Task next;

        public Task(String taskId, String taskName, String status) {
            this.taskId = taskId;
            this.taskName = taskName;
            this.status = status;
            this.next = null;
        }

        public String getTaskId() {
            return taskId;
        }

        public String getTaskName() {
            return taskName;
        }

        public String getStatus() {
            return status;
        }

        @Override
        public String toString() {
            return taskName + " [" + status + "]";
        }
    }

    private Task head;

    public TaskManagementSystem() {
        head = null;
    }

    // Add Task
    public void add(Task task) {

        if (head == null) {
            head = task;
        } else {
            Task temp = head;

            while (temp.next != null) {
                temp = temp.next;
            }

            temp.next = task;
        }

        System.out.println("Successfully Added: " + task.getTaskName());
    }

    // Search Task
    public void search(String taskId) {

        Task temp = head;

        while (temp != null) {

            if (temp.getTaskId().equals(taskId)) {

                System.out.println("\nTask Found");
                System.out.println("ID: " + temp.getTaskId());
                System.out.println("Name: " + temp.getTaskName());
                System.out.println("Status: " + temp.getStatus());
                return;
            }

            temp = temp.next;
        }

        System.out.println("Task Not Found");
    }

    // Traverse Tasks
    public void traverse() {

        System.out.println("\n--- Task List ---");

        if (head == null) {
            System.out.println("No Tasks Available");
            return;
        }

        Task temp = head;

        while (temp != null) {

            System.out.println(
                    "ID: " + temp.getTaskId()
                    + " | "
                    + temp);

            temp = temp.next;
        }
    }

    // Delete Task
    public void delete(String taskId) {

        if (head == null) {
            System.out.println("List Empty");
            return;
        }

        if (head.getTaskId().equals(taskId)) {
            head = head.next;
            System.out.println("Deleted Task ID: " + taskId);
            return;
        }

        Task temp = head;

        while (temp.next != null &&
               !temp.next.getTaskId().equals(taskId)) {

            temp = temp.next;
        }

        if (temp.next == null) {
            System.out.println("Task Not Found");
        } else {
            temp.next = temp.next.next;
            System.out.println("Deleted Task ID: " + taskId);
        }
    }

    public static void main(String[] args) {

        System.out.println("--- Running Exercise 5: Task Management System ---");

        TaskManagementSystem system =
                new TaskManagementSystem();

        system.add(new Task(
                "T101",
                "Design UI",
                "Pending"));

        system.add(new Task(
                "T102",
                "Develop Backend",
                "In Progress"));

        system.add(new Task(
                "T103",
                "Testing",
                "Pending"));

        system.traverse();

        System.out.println("\nSearching Task T102");
        system.search("T102");

        System.out.println("\nDeleting Task T102");
        system.delete("T102");

        system.traverse();
    }
}