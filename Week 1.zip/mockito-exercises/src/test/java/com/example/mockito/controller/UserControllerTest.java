package com.example.mockito.controller;
import com.example.mockito.entity.User; import com.example.mockito.service.UserService;
import org.junit.jupiter.api.Test; import org.mockito.Mockito;
import org.springframework.test.util.ReflectionTestUtils;
import static org.junit.jupiter.api.Assertions.*;
public class UserControllerTest {
@Test void testGetUser(){ UserService service=Mockito.mock(UserService.class); UserController c=new UserController();
ReflectionTestUtils.setField(c,"userService",service);
Mockito.when(service.getUserById(1L)).thenReturn(new User(1L,"John"));
assertEquals("John", c.getUser(1L).getBody().getName());}
}