package com.example.mockito.integration;
import org.junit.jupiter.api.Test; import static org.junit.jupiter.api.Assertions.*;
public class UserIntegrationTest { @Test void test(){ assertTrue(true); } }