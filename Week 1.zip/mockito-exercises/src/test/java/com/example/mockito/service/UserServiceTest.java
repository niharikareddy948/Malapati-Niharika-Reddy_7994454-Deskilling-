package com.example.mockito.service;
import com.example.mockito.entity.User; import com.example.mockito.repository.UserRepository;
import org.junit.jupiter.api.Test; import org.mockito.Mockito;
import org.springframework.test.util.ReflectionTestUtils;
import java.util.Optional; import static org.junit.jupiter.api.Assertions.*;
public class UserServiceTest {
@Test void testGetUser(){ UserRepository repo=Mockito.mock(UserRepository.class); UserService s=new UserService();
ReflectionTestUtils.setField(s,"userRepository",repo);
Mockito.when(repo.findById(1L)).thenReturn(Optional.of(new User(1L,"Alice")));
assertEquals("Alice", s.getUserById(1L).getName());}
}