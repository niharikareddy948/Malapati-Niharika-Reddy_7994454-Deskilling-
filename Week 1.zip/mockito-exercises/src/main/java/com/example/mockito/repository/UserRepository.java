package com.example.mockito.repository;
import com.example.mockito.entity.User; import java.util.Optional;
public interface UserRepository { Optional<User> findById(Long id); }