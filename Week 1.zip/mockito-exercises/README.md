Run:
mvn clean install
mvn spring-boot:run
mvn test