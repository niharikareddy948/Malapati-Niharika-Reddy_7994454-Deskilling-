Open terminal
1. mvn clean install
2. mvn test
3. mvn spring-boot:run
App URL: http://localhost:8080/users/1
