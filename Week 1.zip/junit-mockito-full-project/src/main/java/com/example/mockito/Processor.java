package com.example.mockito; 
public interface Processor{
    void process(String v);
}