package com.example.mockito;
 public interface LoggerService{
    void log(String m);
}