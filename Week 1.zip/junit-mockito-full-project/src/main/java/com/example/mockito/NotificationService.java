package com.example.mockito; 
public interface NotificationService{
    void send();
}