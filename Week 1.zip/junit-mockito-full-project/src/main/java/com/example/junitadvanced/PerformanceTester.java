package com.example.junitadvanced;
 public class PerformanceTester{
    public void performTask() throws Exception{
        Thread.sleep(500);
    }}