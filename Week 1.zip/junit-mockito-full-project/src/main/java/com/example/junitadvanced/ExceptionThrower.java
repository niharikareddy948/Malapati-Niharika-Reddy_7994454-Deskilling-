package com.example.junitadvanced;
 public class ExceptionThrower{
    public void throwException(){
        throw new RuntimeException("Error");
    }}