package com.example.junitbasic; 
public class StringUtils{
    public String toUpper(String s){
        return s.toUpperCase();
    }}