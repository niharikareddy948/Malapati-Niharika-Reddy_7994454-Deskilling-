# Complete JUnit + Mockito Exercises Project
Run: mvn test