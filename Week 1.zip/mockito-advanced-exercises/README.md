mockito-advanced-exercises
Run with: mvn test
This is a starter package generated for download.